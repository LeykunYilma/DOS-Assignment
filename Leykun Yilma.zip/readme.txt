This is an implementation of a simple denial of service attack. It continuously sends
data to the receiving end, therefore, making the server unable to respond to other
legitimate requests. It was tried and succeeded by connecting with a mobile hotspot and
then running the DOS.py script, after which point, the hotspot stopped responding.